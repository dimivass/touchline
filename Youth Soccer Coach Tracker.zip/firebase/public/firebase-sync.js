/* Touchline · Firebase sync
 *
 * A classic script that lazily pulls the Firebase modular SDK from the CDN.
 * It is inert unless window.TOUCHLINE_FIREBASE_CONFIG is present and filled in,
 * so the design preview and the offline single-file build keep running on
 * localStorage alone with nothing to configure.
 *
 * Data model — one document per team:
 *   teams/{ownerUid}
 *     name      string
 *     members   { uid: "owner" | "coach" }
 *     invites   [ email ]        second coach signs in with Google, reads/writes by email
 *     blob      string           the whole season as JSON — sidesteps every Firestore
 *                                field-type restriction and keeps a write atomic
 *     savedAt   number           ms epoch, used for last-write-wins
 *     savedBy   string           display name of whoever wrote last
 *
 * Offline is the default, not a fallback: Firestore's IndexedDB cache serves reads
 * and queues writes, so a session logged at a field with no signal lands when the
 * phone next sees the network.
 */
window.TouchlineSync = (function () {
  var CDN = "https://www.gstatic.com/firebasejs/10.12.2/";
  var LIMIT = 700 * 1024; // warn well before Firestore's 1 MiB document ceiling

  var mods = null, app = null, auth = null, db = null, stopDoc = null;
  var listeners = [], onRemote = null, docRef = null, queued = null, writing = false;

  var st = {
    status: "off",   // off | loading | signedout | ready | error
    user: null,      // display name or email
    teamId: null,
    at: null,        // ms epoch of the last successful cloud write or read
    pending: false,  // a write is queued or in flight
    bytes: 0,
    big: false,
    msg: ""
  };

  function cfg() { return window.TOUCHLINE_FIREBASE_CONFIG || null; }

  function available() {
    var c = cfg();
    return !!(c && c.apiKey && c.projectId && String(c.apiKey).indexOf("PASTE") < 0);
  }

  function emit(patch) {
    if (patch) Object.assign(st, patch);
    var snap = Object.assign({}, st);
    listeners.forEach(function (f) { try { f(snap); } catch (e) {} });
  }

  function onChange(fn) { listeners.push(fn); fn(Object.assign({}, st)); }

  async function sdk() {
    if (mods) return mods;
    var r = await Promise.all([
      import(CDN + "firebase-app.js"),
      import(CDN + "firebase-auth.js"),
      import(CDN + "firebase-firestore.js")
    ]);
    mods = { app: r[0], auth: r[1], fs: r[2] };
    return mods;
  }

  /* Bring up the SDK, restore any existing session, and start watching the team doc. */
  async function start(remoteHandler) {
    onRemote = remoteHandler;
    if (!available()) { emit({ status: "off" }); return; }
    emit({ status: "loading", msg: "" });
    try {
      var m = await sdk();
      app = m.app.initializeApp(cfg());
      auth = m.auth.getAuth(app);
      db = m.fs.initializeFirestore(app, {
        localCache: m.fs.persistentLocalCache({ tabManager: m.fs.persistentMultipleTabManager() })
      });
      m.auth.onAuthStateChanged(auth, function (u) { bind(u); });
    } catch (e) {
      emit({ status: "error", msg: friendly(e) });
    }
  }

  function bind(u) {
    if (stopDoc) { stopDoc(); stopDoc = null; }
    if (!u) {
      docRef = null;
      emit({ status: "signedout", user: null, teamId: null, pending: false });
      return;
    }
    var m = mods;
    docRef = m.fs.doc(db, "teams", u.uid);
    emit({
      status: "ready",
      user: u.displayName || u.email || "Signed in",
      teamId: u.uid
    });

    stopDoc = m.fs.onSnapshot(docRef, function (snap) {
      if (!snap.exists()) { seed(u); return; }
      var d = snap.data() || {};
      if (typeof d.blob === "string" && onRemote) {
        onRemote(d.blob, Number(d.savedAt) || 0, d.savedBy || "");
      }
      emit({ at: Number(d.savedAt) || null, bytes: (d.blob || "").length, big: (d.blob || "").length > LIMIT });
    }, function (e) {
      emit({ status: "error", msg: friendly(e) });
    });
  }

  /* First sign-in on a fresh project: create the team document this coach owns. */
  async function seed(u) {
    var m = mods, members = {};
    members[u.uid] = "owner";
    try {
      await m.fs.setDoc(docRef, {
        name: "Touchline",
        members: members,
        invites: [],
        blob: "",
        savedAt: 0,
        savedBy: u.displayName || u.email || ""
      });
    } catch (e) { emit({ status: "error", msg: friendly(e) }); }
  }

  async function signInGoogle() {
    if (!auth) return;
    var m = mods;
    var provider = new m.auth.GoogleAuthProvider();
    try {
      await m.auth.signInWithPopup(auth, provider);
    } catch (e) {
      // Popups are blocked in some in-app browsers and on iOS standalone PWAs.
      if (String(e && e.code).indexOf("popup") >= 0) {
        try { await m.auth.signInWithRedirect(auth, provider); return; } catch (e2) {}
      }
      emit({ status: "signedout", msg: friendly(e) });
    }
  }

  async function signOutNow() {
    if (!auth) return;
    try { await mods.auth.signOut(auth); } catch (e) {}
  }

  /* Queue a write. Coalesces bursts of taps into one document write. */
  function push(blob, savedAt) {
    if (st.status !== "ready" || !docRef) return;
    queued = { blob: blob, savedAt: savedAt || Date.now() };
    emit({ pending: true, bytes: blob.length, big: blob.length > LIMIT });
    drain();
  }

  async function drain() {
    if (writing || !queued || !docRef) return;
    writing = true;
    var job = queued; queued = null;
    try {
      await mods.fs.setDoc(docRef, {
        blob: job.blob,
        savedAt: job.savedAt,
        savedBy: st.user || ""
      }, { merge: true });
      emit({ at: job.savedAt, pending: !!queued, msg: "" });
    } catch (e) {
      emit({ pending: false, msg: friendly(e) });
    }
    writing = false;
    if (queued) drain();
  }

  function friendly(e) {
    var c = String((e && e.code) || "");
    if (c.indexOf("permission-denied") >= 0) return "The database rejected that. Publish the Firestore rules from the package README.";
    if (c.indexOf("unavailable") >= 0) return "No connection. Your edits are saved on this phone and will sync when signal returns.";
    if (c.indexOf("auth/operation-not-allowed") >= 0) return "Google sign-in is switched off in this Firebase project. Enable it under Authentication.";
    if (c.indexOf("auth/unauthorized-domain") >= 0) return "This web address is not on the Firebase authorised domains list.";
    if (c.indexOf("popup-closed") >= 0 || c.indexOf("cancelled") >= 0) return "Sign-in was cancelled.";
    return (e && e.message) || "Something went wrong talking to Firebase.";
  }

  return {
    available: available,
    onChange: onChange,
    start: start,
    signInGoogle: signInGoogle,
    signOut: signOutNow,
    push: push,
    limit: LIMIT
  };
})();
