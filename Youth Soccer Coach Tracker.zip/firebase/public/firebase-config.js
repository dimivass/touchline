/* Touchline · Firebase configuration
 *
 * Paste the six values from your Firebase web app here, save, redeploy.
 * Until apiKey stops saying PASTE, Touchline runs offline-only on each device.
 *
 * These values are not secrets. A Firebase web config is public by design —
 * what protects your season is the Firestore rules file, which only lets a
 * signed-in coach read and write their own team document.
 */
window.TOUCHLINE_FIREBASE_CONFIG = {
  apiKey: "PASTE_YOUR_API_KEY",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "PASTE_SENDER_ID",
  appId: "PASTE_APP_ID"
};
