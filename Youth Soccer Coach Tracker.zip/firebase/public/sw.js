/* Touchline · app-shell cache
 *
 * Firestore keeps the SEASON available offline; this keeps the APP itself
 * available offline. Bump CACHE on every deploy so coaches get the new build.
 */
const CACHE = "touchline-v2";
const SHELL = [
  "./", "index.html", "support.js", "firebase-sync.js", "image-slot.js",
  "manifest.webmanifest", "icon-192.png", "icon-512.png",
  "_ds/modernist-4c312b63-feee-48c6-b854-caffc96e5af9/styles.css", "_ds/modernist-4c312b63-feee-48c6-b854-caffc96e5af9/_ds_bundle.js"
];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys()
      .then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);

  // Never stand between the app and Firebase, or fonts.
  if (url.origin !== self.location.origin) return;

  // The config must be able to change without waiting for a cache to expire.
  if (url.pathname.endsWith("/firebase-config.js")) {
    e.respondWith(fetch(req).catch(() => caches.match(req)));
    return;
  }

  e.respondWith(
    caches.match(req).then(hit => {
      const live = fetch(req).then(res => {
        if (res && res.ok) caches.open(CACHE).then(c => c.put(req, res.clone()));
        return res;
      }).catch(() => hit);
      return hit || live;
    })
  );
});
