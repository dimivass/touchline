# Touchline on Firebase

This folder is a complete, deployable Firebase project. It fixes the one real
problem with the app so far: the season lived in a single browser, and nothing
outside that browser knew about it.

After deploying, Touchline gets:

- **One account, every device.** Sign in once and your phone, tablet and laptop
  all show the same squad, the same ratings, the same season.
- **Offline first, not offline-broken.** Firestore serves the season from the
  phone's own storage and queues your writes. A session logged at a field with
  no bars lands the moment you get signal back — you never see a spinner and
  never lose a tap.
- **Installable.** Add to Home Screen and it opens like an app, full screen,
  with its own icon, and it opens with no signal at all.
- **A backup you don't have to remember.** The download-a-file flow is still
  there, but it stops being the only thing between you and a lost season.

---

## What's in here

```
firebase.json         Hosting + Firestore config
firestore.rules       Who can read and write a team — read this one
.firebaserc.example   Rename to .firebaserc and add your project id
public/
  index.html          The app
  firebase-config.js  ← the only file you have to edit
  firebase-sync.js    Auth, Firestore, offline cache
  support.js          App runtime
  image-slot.js       Player headshot slots
  sw.js               App-shell cache, so it opens offline
  manifest.webmanifest, icon-192.png, icon-512.png
  _ds/                Design system stylesheet and components
```

---

## Setup, once

**1. Create the project.** Go to console.firebase.google.com → **Add project**.
Name it `touchline` (the id it generates is what you'll paste below). Google
Analytics is not needed — turn it off.

**2. Turn on sign-in.** Left sidebar → **Build → Authentication** → **Get
started** → **Google** → toggle **Enable** → **Save**. Google is the only
provider the app uses: one tap, no password to lose.

**3. Create the database.** **Build → Firestore Database** → **Create
database** → pick the region closest to you → start in **production mode**.
Production mode denies everything until you publish the rules in step 6, which
is exactly what you want.

**4. Register the web app.** Project settings (the gear) → scroll to **Your
apps** → the **web** icon `</>`. Nickname it `Touchline`, skip Hosting setup
here, **Register app**. Firebase shows you a `firebaseConfig` block.

**5. Paste the config.** Open `public/firebase-config.js` and copy the six
values across. That's the whole edit. (These values are not secrets — a
Firebase web config is public by design. What protects your season is
`firestore.rules`.)

**6. Deploy.** In a terminal, from inside this folder:

```sh
npm install --global firebase-tools
firebase login
cp .firebaserc.example .firebaserc     # then put your project id in it
firebase deploy
```

Firebase prints your URL: `https://YOUR-PROJECT.web.app`. Open it on your
phone, tap **Sign in with Google** on the Season → Data screen, and then use
the browser's Share → **Add to Home Screen**.

**7. Check the rules took.** Firestore Database → **Rules** tab should show the
contents of `firestore.rules`. If it still shows the default deny-all,
`firebase deploy --only firestore:rules`.

---

## Moving your current season across

The season already in your browser doesn't travel by itself.

1. In your existing copy: **Season → Data → Download the season**.
2. Open the deployed app, sign in.
3. **Season → Data → Choose a backup file**, pick that file.

It uploads on the next tap and appears on your other devices within seconds.

---

## Adding an assistant coach

The rules already support it, the app UI doesn't yet. To do it by hand:
Firestore Database → `teams` → your document → `invites` → add their Google
address to the array. They sign in with that Google account and get the same
season, live. Anything they change, you see.

Ask me when you want this as a screen in the app rather than a console edit.

---

## What this costs

Nothing, realistically. One team's season is a few hundred kilobytes in a
single document. The Firebase free tier covers 50,000 document reads and 20,000
writes a day; a coach logging a game hard might use a few hundred writes. You
would have to run a few hundred teams before the free tier noticed.

---

## Two things worth knowing

**Last write wins, per season.** If you edit the same season on two devices
while both are offline, the one that reconnects last overwrites the other. For
one coach on a phone and a laptop this is the right trade — the alternative,
merging field by field, produces a season that neither device ever showed you.
If you'll routinely have two people editing at once, tell me and I'll split the
document per game and per player so edits stop colliding.

**Watch the size.** Everything lives in one Firestore document, which caps at
1 MB. The Data screen warns you past 700 KB. A single season of 24 players will
not get close; several seasons of rating history eventually could. Start a
fresh season each year and download the old one.

---

## Redeploying after a change

```sh
firebase deploy --only hosting
```

Bump `CACHE = "touchline-v1"` in `public/sw.js` when you do, or phones will
keep serving the previous build from their cache.
